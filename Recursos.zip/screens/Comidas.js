import React, {useEffect, useState} from 'react';
import { StyleSheet, Text, View, Image, FlatList } from 'react-native';

import CustomButton from '../components/Botones';


export default  function App( {navigation} ) {

  async function Agregar_1() {

    proteina = 10;
    carbidratos = 15;
    kalorias = 500;
 
 }  

 const opciones = [
  { id: '01', nombre: 'Gorditas', imagen: require('../Imagenes/Gordita.jpg') },
  { id: '02', nombre: 'Flautas', imagen: require('../Imagenes/Flautas.jpg') },
  { id: '03', nombre: 'Galletas', imagen: require('../Imagenes/Galletas.jpg') },
  { id: '04', nombre: 'Chilaquiles', imagen: require('../Imagenes/Chilaquiles.jpg') },
  { id: '05', nombre: 'Hot cakes', imagen: require('../Imagenes/Hotcakes.jpg') },
  { id: '06', nombre: 'Muffin de chocolate', imagen: require('../Imagenes/MuffinChocolate.jpg') },
  { id: '07', nombre: 'Torta', imagen: require('../Imagenes/Torta.jpg') },
  { id: '08', nombre: 'Sincronizada', imagen: require('../Imagenes/Sincronizadas.jpg') },
  { id: '09', nombre: 'Moyete', imagen: require('../Imagenes/Moyete.jpg') },
  { id: '10', nombre: 'Opción', imagen: require('../Imagenes/Maruchan.jpg') },
];

const [seleccion, setSeleccion] = useState(null);

const renderItem = ({ item }) => (
  <View style={{ margin: 10 }}>
    <Text>{item.nombre}</Text>
    <Image source={item.imagen} style={{ width: 200, height: 200 }} />
    <CustomButton Text="Seleccionar" action={() => setSeleccion(item)} />
  </View>

 
)

  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Text>Seleccionado: {seleccion ? seleccion.nombre : 'Ninguno'}</Text>
      <FlatList
        data={opciones}
        renderItem={renderItem}
        keyExtractor={(item) => item.id}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  item: {
    backgroundColor: '#f9c2ff',
    padding: 20,
    marginVertical: 8,
    marginHorizontal: 16,
  },
  title: {
    fontSize: 32,
  }
});
