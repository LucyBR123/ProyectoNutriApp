import React, {useEffect, useState} from 'react';
import { StyleSheet, Text, View, Image, FlatList } from 'react-native';

//import CustomButton from '../components/Botones';

const Backend = ({ route }) => {
    const { datos } = route.params;
  
    const listaDeElementos = [
      { id: '1', nombre: 'Elemento 1' },
      { id: '2', nombre: 'Elemento 2' },
      { id: '3', nombre: 'Elemento 3' },
      // Agrega más elementos según sea necesario
    ];
  
    const renderItem = ({ item }) => (
      <View>
        <Text>{item.nombre}</Text>
      </View>
    );
  
    return (
      <View>
        <Text>{datos.mensaje}</Text>
        <FlatList
          data={listaDeElementos}
          renderItem={renderItem}
          keyExtractor={(item) => item.id}
        />
      </View>
    );
  };
  
 
 
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  item: {
    backgroundColor: '#f9c2ff',
    padding: 20,
    marginVertical: 8,
    marginHorizontal: 16,
  },
  title: {
    fontSize: 32,
  }
});

export default Backend;