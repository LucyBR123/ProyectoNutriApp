import React, {useEffect, useState} from 'react';
import { StyleSheet, Text, View, Image, FlatList } from 'react-native';

import CustomButton from '../components/Botones';


export default  function App( {navigation} ) {

  const opciones = [
    { id: '01', nombre: 'Agua de Orchata 1L', imagen: require('../Imagenes/AguaOrchata.jpg') },
    { id: '02', nombre: 'Agua de Orchata 1/2', imagen: require('../Imagenes/AguaOrchata.jpg') },
    { id: '03', nombre: 'Agua de Jamaica 1L', imagen: require('../Imagenes/AguaJamaica.jpg') },
    { id: '04', nombre: 'Agua de jamaica 1/2', imagen: require('../Imagenes/AguaJamaica.jpg') },
    { id: '05', nombre: 'Gatorade', imagen: require('../Imagenes/Gaytoray.jpg') },
    { id: '05', nombre: 'Arizona', imagen: require('../Imagenes/AriZona.jpg') },
  ];
  
  const [seleccion, setSeleccion] = useState(null);
  
  const renderItem = ({ item }) => (
    <View style={{ margin: 10 }}>
      <Text>{item.nombre}</Text>
      <Image source={item.imagen} style={{ width: 75, height: 75 }} />
      <CustomButton Text="Seleccionar" action={() => navigation.navigate('Backend',{ item })} />
    </View>
  )
  
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
        <Text>Seleccionado: {seleccion ? seleccion.nombre : 'Ninguno'}</Text>
        <FlatList
          data={opciones}
          renderItem={renderItem}
          keyExtractor={(item) => item.id}
        />
      </View>
    );
  }
  
  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: '#fff',
      alignItems: 'center',
      justifyContent: 'center',
    },
    item: {
      backgroundColor: '#f9c2ff',
      padding: 20,
      marginVertical: 8,
      marginHorizontal: 16,
    },
    title: {
      fontSize: 32,
    }
  });




  