import { StatusBar } from 'expo-status-bar';
import React, {useState, useEffect} from 'react';
import { StyleSheet, Text, View, TextInput, FlatList } from 'react-native';

import CustomButton from '../components/Botones';

export default function App( {navigation} ) {




  async function Comida(){
    navigation.navigate("Comidas");
  }
  async function Bebida(){
    navigation.navigate("Bebidas");
  }

  return (
    <View style={styles.container}>
      <Text style={styles.titulo }>Bienvenidos a Nutribullet</Text>

      <CustomButton Text={"Agregar Bebida"} action={Bebida}/>
      <CustomButton Text={"Agregar Aliemntos"} action={Comida}/>

      <StatusBar style="auto" />
    </View>
  );
  }

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  input_login: {
    width: '90%', 
    height: 50, 
    backgroundColor: 'white',
    borderColor: 'rgba(0, 0, 0, 0.5)',
    borderWidth:1,
    borderRadius: 5,
    fontSize:22,
    paddingLeft:10,
    marginBottom: 20
  },

  titulo:{
    fontSize: 40,
    marginBottom:40,
    fontWeight: 'bold'
  }
});

