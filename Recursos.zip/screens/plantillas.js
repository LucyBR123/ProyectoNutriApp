// LOGIN
/*
import { StatusBar } from 'expo-status-bar';
import React, {useState, useEffect} from 'react';
import { StyleSheet, Text, View, TextInput } from 'react-native';
import  AsyncStorage  from '@react-native-async-storage/async-storage';

import CustomButton from '../components/Botones';


export default function App( {navigation} ) {


  useEffect(function(){  navigation.setOptions({
    headerShown: false
  });
});

  const [username, setUsername] = useState('MUNDO');
  const [password, setPassword] = useState("");  

  async function login(){
    const data = {
      user: username,
      pass: password
    }

    try {
       await AsyncStorage.setItem("data", JSON.stringify(data));
       console.log("se guardo correctamente");
      
      }
      catch (e) {
        console.log(e);
      }

    navigation.navigate("Main");
  }

  return (
    <View style={styles.container}>
      <Text style={styles.titulo }>Hola, {username}</Text>

    <TextInput 
    onChangeText={setUsername}
    style={styles.input_login} 
    placeholder="Usuario"/>
    <TextInput 
    onChangeText={setPassword}
    style={styles.input_login} 
    placeholder="Contraseña" 
    secureTextEntry={true}/>

    <CustomButton Text={"Iniciar sesion"} action={login}/>

      <StatusBar style="auto" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  input_login: {
    width: '90%', 
    height: 50, 
    backgroundColor: 'white',
    borderColor: 'rgba(0, 0, 0, 0.5)',
    borderWidth:1,
    borderRadius: 5,
    fontSize:22,
    paddingLeft:10,
    marginBottom: 20
  },

  titulo:{
    fontSize: 40,
    marginBottom:40,
    fontWeight: 'bold'
  }
});
*/

























// MAIN

/*
import React, {useEffect, useState} from 'react';
import { StyleSheet, View, FlatList, Image} from 'react-native';

export default  function App( {navigation} ) {

  const [dogs, setDogs] = useState ();
  const [loading, setloading]= useState (false);


  useEffect(function(){  navigation.setOptions({
    headerShown: true,
    headerTintColor: "black",
    headerStyle: {
       backgroundColor: "green"
    }
  });
  loadDogs();
}, []);

async function loadDogs() {

   const response = await fetch('https://dog.ceo/api/breeds/image/random/50');
   const data = await response.json();
   const d = data.message.map((url, id )=>{
    return {
      id:"dog-url-image-"+id,
      url:url
    }
   });
   setDogs(d);
}

  const Item = (props) => (
    <View style={styles.item}>
      <Image  
      style = {{ width:200, height:200 }}
      source={{  
          uri: props.url, 
        }}/>
    </View>
  );

  const renderItem = ({item}) => (
    <Item url = {item.url} />
  )
  
  return (
    <View style={styles.container}>
       <FlatList
        data={dogs}
        refreshing={loading}
        onRefresh={loadDogs}
        renderItem={renderItem}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  item: {
    backgroundColor: '#f9c2ff',
    padding: 20,
    marginVertical: 8,
    marginHorizontal: 16,
  },
  title: {
    fontSize: 32,
  }
});
*/
