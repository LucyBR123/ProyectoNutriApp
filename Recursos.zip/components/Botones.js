import react from 'react';
import { TouchableOpacity, Text } from 'react-native';

export default function CustomButton (props) {
    return (
    <TouchableOpacity 
    onPress={props.action}
    style= {{
        backgroundColor:'green',
        width:170, 
        height:55,
        justifyContent: 'center',
        alignItems:'center',
        fontSize:22
    }}>
    <Text>{props.Text}</Text>
  </TouchableOpacity>
);

}



